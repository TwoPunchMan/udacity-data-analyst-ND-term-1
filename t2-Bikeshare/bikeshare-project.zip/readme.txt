Help sites:
-----------

https://stackoverflow.com/
https://docs.python.org/3/library/string.html#format-examples
https://docs.python.org/3/library/csv.html
https://pandas.pydata.org/pandas-docs/stable/genindex.html#M
https://duckduckgo.com/
https://dataquest.io/
https://www.tutorialspoint.com/python_pandas/python_pandas_dataframe.htm